package com.kodnest.tunehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectTuneHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectTuneHubApplication.class, args);
	}

}
